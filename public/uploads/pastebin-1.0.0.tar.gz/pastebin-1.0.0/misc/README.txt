Miscellaneous support files

- paste.profile.js
  This is a build profile for the pastebin application. 
  
  To create a custom build, first copy the public/js-src/paste directory to your
  Dojo source build. Then, place the paste.profile.js file in the
  util/buildscripts/profiles/ directory of your Dojo source distribution. From
  the util/buildscripts directory, execute the line provided in the header of
  the profile to create a custom build.  You can then use this custom build in
  place of the shipped JS source.
