/*
	Copyright (c) 2004-2008, The Dojo Foundation
	All Rights Reserved.

	Licensed under the Academic Free License version 2.1 or above OR the
	modified BSD license. For more information on Dojo licensing, see:

		http://dojotoolkit.org/book/dojo-book-0-9/introduction/licensing
*/


if(!dojo._hasResource["dojo._base.browser"]){dojo._hasResource["dojo._base.browser"]=true;dojo.provide("dojo._base.browser");dojo.require("dojo._base.window");dojo.require("dojo._base.event");dojo.require("dojo._base.html");dojo.require("dojo._base.NodeList");dojo.require("dojo._base.query");dojo.require("dojo._base.xhr");dojo.require("dojo._base.fx");if(dojo.config.require){dojo.forEach(dojo.config.require,"dojo['require'](item);");}}