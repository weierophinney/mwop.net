/*
	Copyright (c) 2004-2008, The Dojo Foundation
	All Rights Reserved.

	Licensed under the Academic Free License version 2.1 or above OR the
	modified BSD license. For more information on Dojo licensing, see:

		http://dojotoolkit.org/book/dojo-book-0-9/introduction/licensing
*/


if(!dojo._hasResource["dojo._base"]){dojo._hasResource["dojo._base"]=true;dojo.provide("dojo._base");dojo.require("dojo._base.lang");dojo.require("dojo._base.declare");dojo.require("dojo._base.connect");dojo.require("dojo._base.Deferred");dojo.require("dojo._base.json");dojo.require("dojo._base.array");dojo.require("dojo._base.Color");dojo.requireIf(dojo.isBrowser,"dojo._base.browser");}