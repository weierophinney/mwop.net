<?php
/**
 * Exception for model classes
 * 
 * @uses      Exception
 * @package   Paste
 * @license   New BSD {@link http://framework.zend.com/license/new-bsd}
 * @version   $Id: $
 */
class Model_Exception extends Exception
{
}
